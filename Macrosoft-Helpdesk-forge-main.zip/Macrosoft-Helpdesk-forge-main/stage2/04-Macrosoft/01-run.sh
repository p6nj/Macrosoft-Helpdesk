#!/bin/bash -e

# hostname, fortune
echo heaven > ${ROOTFS_DIR}/etc/hostname
on_chroot << EOF
/usr/games/fortune > /etc/motd || echo "can't get a fortune, emptying banner" && echo > /etc/motd
EOF

# users
on_chroot <<EOF
echo coco.caca.48 > password
echo coco.caca.48 >> password
# create groups if they don't exist
groupadd p6nj || groupadd netdev || groupadd gpio || groupadd i2c || groupadd spi || true
useradd -g p6nj -G adm,dialout,cdrom,sudo,audio,video,plugdev,games,users,input,render,netdev,gpio,i2c,spi -m p6nj
passwd p6nj < password
passwd < password
echo Warning: overriding pi file in sudoers for p6nj
echo "p6nj ALL=(ALL) NOPASSWD: ALL" > /etc/sudoers.d/010_pi-nopasswd
echo Warning: disabling user configuration dialog
systemctl mask userconfig.service
EOF

# git config
on_chroot << EOF
git config --global url."https://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:x-oauth-basic@github.com/".insteadOf "https://github.com/"
EOF

# autologin
mkdir -p /etc/systemd/system/getty@tty1.service.d
echo "[Service]
ExecStart=
ExecStart=-/sbin/mingetty --autologin p6nj --noclear tty1" > /etc/systemd/system/getty@tty1.service.d/override.conf

# R
# on_chroot << EOF
# echo this will take a looooooong time
# R -e "install.packages('shiny')"
# EOF

# server installation
on_chroot << EOF
git clone https://github.com/p6nj/Macrosoft-Helpdesk /home/p6nj/.github
/home/p6nj/.github/install.sh
EOF